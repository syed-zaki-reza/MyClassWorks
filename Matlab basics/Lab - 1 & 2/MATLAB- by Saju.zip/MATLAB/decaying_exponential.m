B = 1;
r = 0.85;
n = -10:10;
x = B*r.^n;
plot(n, x)