A = 1;
omega = 2*pi/12;
phi = 0;
n = -10:10;
y = A*sin(omega*n);
stem(n, y)

