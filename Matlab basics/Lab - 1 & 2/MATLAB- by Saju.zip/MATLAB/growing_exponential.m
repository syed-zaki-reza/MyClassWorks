B = 1;
a = 1;
t = 0:1;
x = B*exp(a*t);
plot(t, x)