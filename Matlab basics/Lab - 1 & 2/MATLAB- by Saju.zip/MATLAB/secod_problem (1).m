[X,Y,Z] = peaks;
surf(X,Y,Z)
xlabel('x-axis')
ylabel('y-axis')
xlim([-inf 0]) 
ylim([-1 inf])
