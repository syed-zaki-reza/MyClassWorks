x = 1:10;
m=10;
c=5;
y = m*x + c;
stem(x,y)